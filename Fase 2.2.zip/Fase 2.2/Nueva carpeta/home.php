<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurante la Tatemada</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <header>
        <div class="auth-buttons">
            <a href="index.php">Iniciar sesión</a> <!-- Redirige al login.php -->
        </div>
        <br>
        <h1>Restaurante La Tatemada</h1>
    </header>

    <main>
        <!-- Sección Hero -->
        <section class="hero">
            <h2>Bienvenido a La Tatemada</h2>
            <p>Disfruta de la mejor comida desde la comodidad de tu hogar.</p>
        </section>

        <!-- Sección Menú -->
        <section id="menu" class="menu">
            <a href="menu.php"><h2>Nuestro Menú</h2></a>
            <div class="menu-items">
                <div class="menu-item">
                    <img src="assets/img/tacos.png" alt="Tacos"> <!-- Ajusta la ruta de las imágenes -->
                    <h3>Tacos</h3>
                    <p>Deliciosos tacos de pollo al limón y cebolla caramelizada.</p>
                </div>
                <div class="menu-item">
                    <img src="assets/img/ceviche.png" alt="Ceviche">
                    <h3>Ceviche</h3>
                    <p>Ceviche de reineta, salmón o mixto.</p>
                </div>
                <div class="menu-item">
                    <img src="assets/img/quesadillas.png" alt="Quesadillas">
                    <h3>Quesadillas</h3>
                    <p>Quesadillas con tres guarniciones. Tenemos opciones vegetarianas, carnes, pollo o camarón empanado.</p>
                </div>
            </div>
        </section>

        <!-- Sección Nosotros -->
        <section id="nosotros" class="about-us">
            <h2>Sobre Nosotros</h2>
            <p>En La Tatemada, transformamos cada comida en una experiencia inolvidable. Ubicados en la terraza del patio comedor en calle Freire #928 Local D, frente al liceo comercial de Quilpué, te ofrecemos un espacio acogedor para disfrutar de los sabores que tanto te gustan. <br><br>

Nos especializamos en pastelería artesanal, almuerzos caseros y deliciosas onces, preparados con ingredientes de la más alta calidad y un toque de cariño en cada plato. Ya sea que quieras disfrutar de un almuerzo sustancioso, una merienda reconfortante o un dulce bocado, La Tatemada es el lugar perfecto para compartir momentos deliciosos. <br><br>

Te invitamos a visitarnos y descubrir por qué somos el lugar favorito para disfrutar de lo mejor de la gastronomía local. ¡En La Tatemada, siempre encontrarás algo delicioso que te hará volver por más!</p>
        </section>

        <!-- Sección Galería -->
        <section id="galeria" class="gallery">
            <h2>Galería</h2>
            <div class="gallery-items">
                <div class="gallery-item">
                    <img src="assets/img/foto1.png" alt="Interior del restaurante"> <!-- Ajusta las rutas de las imágenes -->
                </div>
                <div class="gallery-item">
                    <img src="assets/img/foto5.png" alt="Plato de comida">
                </div>
                <div class="gallery-item">
                    <img src="assets/img/foto6.png" alt="Plato de comida">
                </div>
                <div class="gallery-item">
                    <img src="assets/img/foto4.png" alt="Plato de comida">
                </div>
            </div>
        </section>

        <!-- Sección Reservas -->
        <section id="reservas" class="reservations">
            <h2>Reservas</h2>
            <form action="reservar.php" method="POST"> <!-- Ajusta la acción si es necesario -->
                <label for="nombre">Nombre:</label>
                <input type="text" id="nombre" name="nombre" required>

                <label for="telefono">Teléfono:</label>
                <input type="tel" id="telefono" name="telefono" required>

                <label for="fecha">Fecha de la Reserva:</label>
                <input type="date" id="fecha" name="fecha" required>

                <label for="hora">Hora:</label>
                <input type="time" id="hora" name="hora" required>

                <label for="personas">Número de personas:</label>
                <input type="number" id="personas" name="personas" min="1" max="20" required>

                <input type="submit" value="Reservar">
            </form>
        </section>

        <!-- Sección Contacto -->
        <section id="contacto" class="contact">
            <h2>Contacto</h2>
            <p><strong>Dirección:</strong> Terraza en patio comedor ubicados en calle Freire #928 Local B, Quilpué</p>
            <p><strong>Teléfono:</strong> (+56) 9 49244587</p>
            <p><strong>Email:</strong> contacto@latatemada.com</p>
<br>
            <div id="mapa">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3344.400206908265!2d-71.44216768907506!3d-33.045929073442025!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9689d9036fd63d7f%3A0xbedf6c3e4bfd135b!2sLa%20Tatemada!5e0!3m2!1ses!2scl!4v1729380590046!5m2!1ses!2scl" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </section>

    </main>
    <footer>
        <p>&copy; 2024 La Tatemada. Todos los derechos reservados.</p>
        <div class="social-media">
            <a href="#">Facebook</a>
            <a href="#">Instagram</a>
            <a href="#">Twitter</a>
        </div>
    </footer>

    </main>
</body>

</html>