<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conoce nuestro menú</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
    <h1>Conoce nuestro menú</h1>
</body>
</html>