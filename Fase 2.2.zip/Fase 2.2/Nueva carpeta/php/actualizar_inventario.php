<?php
include 'conexion_be.php';

$producto_id = $_POST['producto_id'];
$cantidad = $_POST['cantidad'];

$updateStock = "UPDATE Productos SET stock = stock - '$cantidad' WHERE id = '$producto_id'";
mysqli_query($conexion, $updateStock);
?>
