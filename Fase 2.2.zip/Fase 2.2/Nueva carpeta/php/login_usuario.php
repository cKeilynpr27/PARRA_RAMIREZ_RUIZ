<?php

    include 'conexion_be.php';

    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];

    //contrasena encriptada 
    $contrasena_encriptada = hash('sha512', $contrasena);

    $validar_login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo' and contrasena='$contrasena'");

    if(mysqli_num_rows($validar_login) > 0){
        //si las credenciles coinciden, redirigir a la pagina de bienvenida
        header("location: ../bienvenida.php");
        exit;
    }else{
        //si no coinciden, mostrar un mensaje de error
        echo '
            <script>
                alert("Usuario no existe, por favor verifique los datos introducidos");
                window.location = "../index.php";
            </script>
        ';
        exit;
    }

?>