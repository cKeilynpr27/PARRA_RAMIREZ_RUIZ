<?php
include 'conexion_be.php';

$consulta = "SELECT * FROM Productos WHERE stock > 0";
$resultado = mysqli_query($conexion, $consulta);

$productos = array();
while ($row = mysqli_fetch_assoc($resultado)) {
    $productos[] = $row;
}

echo json_encode($productos);
?>
