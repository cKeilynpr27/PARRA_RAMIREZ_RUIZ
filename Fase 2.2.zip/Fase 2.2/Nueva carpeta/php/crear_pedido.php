<?php
include 'conexion_be.php';

$cliente_id = $_POST['cliente_id'];
$productos = $_POST['productos']; // Productos seleccionados enviados desde el frontend
$total = $_POST['total'];

// Insertar pedido
$insertPedido = "INSERT INTO Pedidos (cliente_id, total) VALUES ('$cliente_id', '$total')";
$resultadoPedido = mysqli_query($conexion, $insertPedido);
$pedido_id = mysqli_insert_id($conexion); // Obtener el ID del pedido insertado

// Insertar detalle de pedido y actualizar inventario
foreach ($productos as $producto) {
    $producto_id = $producto['id'];
    $cantidad = $producto['cantidad'];
    $precio_unitario = $producto['precio'];

    // Insertar en detalle de pedido
    $insertDetalle = "INSERT INTO DetallePedido (pedido_id, producto_id, cantidad, precio_unitario) VALUES ('$pedido_id', '$producto_id', '$cantidad', '$precio_unitario')";
    mysqli_query($conexion, $insertDetalle);

    // Actualizar stock de productos
    $updateStock = "UPDATE Productos SET stock = stock - '$cantidad' WHERE id = '$producto_id'";
    mysqli_query($conexion, $updateStock);
}

// Insertar factura
$insertFactura = "INSERT INTO Facturas (pedido_id, total) VALUES ('$pedido_id', '$total')";
mysqli_query($conexion, $insertFactura);

echo json_encode(["message" => "Pedido y factura generados correctamente."]);
?>
