<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú</title>
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <h1>Menú</h1>
    <main>
        <section id="menu-platos" class="grid-platos">
            <!-- Producto 1 -->
            <div class="plato-item">
                <img src="assets/img/ceviche.png" alt="Ceviche">
                <h3>Ceviche</h3>
                <p>Delicioso ceviche de mariscos frescos.</p>
                <p class="precio">Precio: $12.000</p>
                <input type="number" min="1" value="1" class="cantidad">
                <button onclick="agregarAlCarrito(1, 'Ceviche', 12000)">Agregar al carrito</button>
            </div>

            <!-- Producto 2 -->
            <div class="plato-item">
                <img src="assets/img/tacos.jpg" alt="Tacos al pastor">
                <h3>Tacos al Pastor</h3>
                <p>Tacos al pastor con salsa casera.</p>
                <p class="precio">Precio: $8.000</p>
                <input type="number" min="1" value="1" class="cantidad">
                <button onclick="agregarAlCarrito(2, 'Tacos al Pastor', 8000)">Agregar al carrito</button>
            </div>

            <!-- Producto 3 -->
            <div class="plato-item">
                <img src="assets/img/pasta.jpg" alt="Pasta Alfredo">
                <h3>Pasta Alfredo</h3>
                <p>Pasta alfredo con salsa cremosa.</p>
                <p class="precio">Precio: $10.000</p>
                <input type="number" min="1" value="1" class="cantidad">
                <button onclick="agregarAlCarrito(3, 'Pasta Alfredo', 10000)">Agregar al carrito</button>
            </div>
    </main>

    <section id="carrito">
        <h2>Carrito</h2>
        <ul id="itemsCarrito"></ul>
        <p>Total: $<span id="total">0</span></p>
        <button id="confirmarPedido" disabled>Confirmar Pedido</button>
    </section>

    <script src="assets/js/script.js"></script>
</body>

</html>