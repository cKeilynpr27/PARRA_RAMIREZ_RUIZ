<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Factura</title>
</head>
<body>
    <h1>Factura</h1>
    <p>Pedido ID: <?php echo $_GET['pedido_id']; ?></p>
    <p>Total: $<?php echo $_GET['total']; ?></p>
    <!-- Mostrar más detalles de la factura si es necesario -->
</body>
</html>
