// Ejecutando funciones
document.getElementById("btn__iniciar-sesion").addEventListener("click", iniciarSesion);
document.getElementById("btn__registrarse").addEventListener("click", register);
window.addEventListener("resize", anchoPage);

// Declarando variables
var formulario_login = document.querySelector(".formulario__login");
var formulario_register = document.querySelector(".formulario__register");
var contenedor_login_register = document.querySelector(".contenedor__login-register");
var caja_trasera_login = document.querySelector(".caja__trasera-login");
var caja_trasera_register = document.querySelector(".caja__trasera-register");

// FUNCIONES

// Ajustar el diseño según el ancho de la página
function anchoPage() {
    if (window.innerWidth > 850) {
        caja_trasera_register.style.display = "block";
        caja_trasera_login.style.display = "block";
    } else {
        caja_trasera_register.style.display = "block";
        caja_trasera_register.style.opacity = "1";
        caja_trasera_login.style.display = "none";
        formulario_login.style.display = "block";
        contenedor_login_register.style.left = "0px";
        formulario_register.style.display = "none";
    }
}

anchoPage();

// Cambiar a la vista de iniciar sesión
function iniciarSesion() {
    if (window.innerWidth > 850) {
        formulario_login.style.display = "block";
        contenedor_login_register.style.left = "10px";
        formulario_register.style.display = "none";
        caja_trasera_register.style.opacity = "1";
        caja_trasera_login.style.opacity = "0";
    } else {
        formulario_login.style.display = "block";
        contenedor_login_register.style.left = "0px";
        formulario_register.style.display = "none";
        caja_trasera_register.style.display = "block";
        caja_trasera_login.style.display = "none";
    }
}

// Cambiar a la vista de registro
function register() {
    if (window.innerWidth > 850) {
        formulario_register.style.display = "block";
        contenedor_login_register.style.left = "410px";
        formulario_login.style.display = "none";
        caja_trasera_register.style.opacity = "0";
        caja_trasera_login.style.opacity = "1";
    } else {
        formulario_register.style.display = "block";
        contenedor_login_register.style.left = "0px";
        formulario_login.style.display = "none";
        caja_trasera_register.style.display = "none";
        caja_trasera_login.style.display = "block";
        caja_trasera_login.style.opacity = "1";
    }
}

// Validación básica de formularios
document.querySelector('form.formulario__login').addEventListener('submit', function (e) {
    let correo = document.querySelector('input[name="correo"]').value;
    let contrasena = document.querySelector('input[name="contrasena"]').value;

    if (!correo || !contrasena) {
        e.preventDefault();
        alert('Por favor, completa todos los campos para iniciar sesión.');
    }
});

document.querySelector('form.formulario__register').addEventListener('submit', function (e) {
    let nombreCompleto = document.querySelector('input[name="nombre_completo"]').value;
    let correo = document.querySelector('input[name="correo"]').value;
    let usuario = document.querySelector('input[name="usuario"]').value;
    let contrasena = document.querySelector('input[name="contrasena"]').value;

    if (!nombreCompleto || !correo || !usuario || !contrasena) {
        e.preventDefault();
        alert('Por favor, completa todos los campos para registrarte.');
    }
});

// Animación de desplazamiento suave para enlaces internos
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

let carrito = [];
let total = 0;

// Cargar productos desde el backend
fetch('php/obtener_productos.php')
    .then(response => response.json())
    .then(productos => {
        const menu = document.getElementById('menu');
        productos.forEach(producto => {
            let item = `
                <div class="menu-item">
                    <img src="assets/img/${producto.imagen}" alt="${producto.nombre}">
                    <h3>${producto.nombre}</h3>
                    <p>${producto.descripcion}</p>
                    <p class="precio">Precio: $${producto.precio}</p>
                    <input type="number" min="1" value="1" class="cantidad">
                    <button onclick="agregarAlCarrito(${producto.id}, '${producto.nombre}', ${producto.precio})">Agregar al carrito</button>
                </div>`;
            menu.innerHTML += item;
        });
    });

// Agregar productos al carrito
function agregarAlCarrito(id, nombre, precio) {
    const cantidad = document.querySelector(`.menu-item input[type="number"]`).value;
    carrito.push({ id, nombre, precio, cantidad });
    total += precio * cantidad;
    actualizarCarrito();
}

// Actualizar carrito visualmente
function actualizarCarrito() {
    const itemsCarrito = document.getElementById('itemsCarrito');
    itemsCarrito.innerHTML = '';
    carrito.forEach(item => {
        itemsCarrito.innerHTML += `<li>${item.nombre} - Cantidad: ${item.cantidad} - Total: $${item.precio * item.cantidad}</li>`;
    });
    document.getElementById('total').textContent = total;
    document.getElementById('confirmarPedido').disabled = carrito.length === 0;
}

// Confirmar pedido
document.getElementById('confirmarPedido').addEventListener('click', () => {
    fetch('php/crear_pedido.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cliente_id: 1, productos: carrito, total })
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        window.location.href = 'factura.php';
    });
});
