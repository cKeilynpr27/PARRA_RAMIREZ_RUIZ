-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 02-12-2024 a las 09:06:31
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_la_tatemada`
--
CREATE DATABASE IF NOT EXISTS `bd_la_tatemada` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bd_la_tatemada`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `minimum_stock` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `inventory`
--

INSERT INTO `inventory` (`id`, `name`, `product_id`, `stock`, `minimum_stock`, `quantity`) VALUES
(9, 'leche', 0, 4, 5, 0),
(15, 'azucar', 0, 30, 50, 0),
(16, 'menta', 0, 3, 6, 0),
(18, 'azucar', 0, 44, 45, 0),
(19, 'arroz', 0, 5, 6, 0),
(29, 'Lechuga', 0, 12, 10, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `availability` tinyint(1) NOT NULL DEFAULT 1,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `menu`
--

INSERT INTO `menu` (`id`, `name`, `description`, `price`, `availability`, `category`) VALUES
(65, 'Tostadas con palta + té o café', 'Tostadas de pan marraqueta con palta, incluye té o café', 4990.00, 99, 'Desayunos'),
(66, 'Paila de huevos + té o café', 'Huevos preparados en paila, incluye té o café', 5990.00, 99, 'Desayunos'),
(67, 'Sándwich pollo queso + té o café', 'Sándwich de pollo y queso, incluye té o café', 6990.00, 100, 'Desayunos'),
(68, 'Sándwich pollo italiano + té o café', 'Sándwich de pollo, palta, tomate y mayonesa, incluye té o café', 7990.00, 100, 'Desayunos'),
(69, 'Sándwich mechada queso + té o café', 'Sándwich de mechada con queso, incluye té o café', 7990.00, 100, 'Desayunos'),
(70, 'Sándwich mechada italiana + té o café', 'Sándwich de mechada con palta, tomate y mayonesa, incluye té o café', 8990.00, 97, 'Desayunos'),
(71, 'Cazuela', 'Cazuela con un agregado a elección', 6800.00, 79, 'Tradicionales'),
(72, 'Tomaticán', 'Tomaticán con un agregado a elección', 6800.00, 80, 'Tradicionales'),
(73, 'Guatitas a la Italiana', 'Guatitas preparadas al estilo italiano', 6800.00, 50, 'Tradicionales'),
(74, 'Porotos granados', 'Porotos granados con un agregado a elección', 6800.00, 50, 'Tradicionales'),
(75, 'Pollo rebosado', 'Pollo rebosado con un agregado a elección', 6800.00, 50, 'Tradicionales'),
(76, 'Panqueques rellenos', 'Panqueques rellenos con jamón y queso, cubiertos en salsa blanca', 7990.00, 50, 'Tradicionales'),
(77, 'Pastel de choclo', 'Pastel de choclo tradicional', 8990.00, 50, 'Tradicionales'),
(78, 'Lasagña mixta', 'Lasagña de carne y verduras', 8990.00, 39, 'Pastas'),
(79, 'Ravioles rellenos', 'Ravioles rellenos de ricota con espinaca', 9990.00, 40, 'Pastas'),
(80, 'Ñoquis', 'Ñoquis con salsa a elección', 9990.00, 40, 'Pastas'),
(81, 'Fetuccini', 'Fetuccini con salsa a elección', 8990.00, 39, 'Pastas'),
(82, 'Lomo a lo pobre', 'Lomo acompañado con arroz, papas fritas y huevo', 15990.00, 30, 'Carnes'),
(83, 'Milanesa de pollo', 'Milanesa de pollo apanada en panko', 10990.00, 30, 'Carnes'),
(84, 'Carne mechada', 'Carne mechada con un agregado a elección', 10990.00, 27, 'Carnes'),
(85, 'Costillar al merkén', 'Costillar de cerdo sazonado con merkén', 10990.00, 29, 'Carnes'),
(86, 'Suprema de ave con salsa', 'Suprema de ave acompañada con salsa especial', 13990.00, 30, 'Carnes'),
(87, 'Lomo saltado', 'Lomo saltado con cebolla, tomate y papas fritas', 16990.00, 30, 'Carnes'),
(88, 'Milanesa de lomo', 'Milanesa de lomo apanada en panko', 13990.00, 30, 'Carnes'),
(89, 'Pollo saltado', 'Pollo saltado al estilo oriental', 14990.00, 30, 'Carnes'),
(90, 'Merluza tradicional frita', 'Merluza frita con un agregado a elección', 10990.00, 25, 'Pescados y Mariscos'),
(91, 'Merluza austral frita', 'Merluza austral frita con un agregado a elección', 13990.00, 25, 'Pescados y Mariscos'),
(92, 'Reineta frita', 'Reineta frita con un agregado a elección', 13990.00, 25, 'Pescados y Mariscos'),
(93, 'Reineta a la mantequilla con salsa', 'Reineta con salsa a elección', 14990.00, 25, 'Pescados y Mariscos'),
(94, 'Ceviche de reineta', 'Ceviche de reineta con pimentón, cebolla, palta y cilantro', 14990.00, 23, 'Pescados y Mariscos'),
(95, 'Ceviche mixto', 'Ceviche mixto con salmón, reineta y verduras frescas', 16990.00, 25, 'Pescados y Mariscos'),
(96, 'Risotto', 'Risotto con salsa champiñón o pesto, cilantro y maní', 10990.00, 20, 'Vegetarianos'),
(97, 'Ceviche de quinoa', 'Ceviche de quinoa con champiñón, tomate y palta', 9990.00, 20, 'Vegetarianos'),
(98, 'Ceviche de champiñón', 'Ceviche de champiñón con palta y cilantro', 10990.00, 19, 'Vegetarianos'),
(99, 'Arroz', 'Agregado de arroz', 2500.00, 100, 'Extras'),
(100, 'Puré', 'Puré tradicional', 2500.00, 100, 'Extras'),
(101, 'Papas fritas chica', 'Porción pequeña de papas fritas', 2500.00, 100, 'Extras'),
(102, 'Papas fritas grande', 'Porción grande de papas fritas', 3890.00, 100, 'Extras'),
(103, 'Ensalada chica', 'Ensalada pequeña', 2500.00, 100, 'Extras'),
(104, 'Ensalada grande', 'Ensalada grande con lechuga, tomate y choclo', 4500.00, 100, 'Extras'),
(105, 'Torta del día', 'Torta casera del día', 3500.00, 50, 'Postres'),
(106, 'Cheesecake', 'Cheesecake tradicional', 3500.00, 47, 'Postres'),
(107, 'Pie de limón', 'Pie de limón casero', 3500.00, 49, 'Postres'),
(108, 'Brownie con helado', 'Brownie de chocolate acompañado con helado', 5200.00, 46, 'Postres'),
(109, 'Agua con gas o sin gas', 'Botella de agua mineral', 1500.00, 113, 'Bebestibles'),
(110, 'Bebida', 'Bebida gaseosa', 2000.00, 123, 'Bebestibles'),
(111, 'Jugo mango o chirimoya', 'Jugo natural de mango o chirimoya', 3200.00, 126, 'Bebestibles'),
(112, 'Jugo mixto', 'Jugo natural mixto', 3500.00, 126, 'Bebestibles'),
(113, 'Limonada', 'Limonada tradicional o con jengibre', 3200.00, 127, 'Bebestibles'),
(114, 'Pisco sour', 'Pisco sour clásico', 3500.00, 126, 'Tragos'),
(115, 'Mango sour', 'Mango sour clásico', 3500.00, 126, 'Tragos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mesas`
--

CREATE TABLE `mesas` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL,
  `status` varchar(50) DEFAULT 'Disponible'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mesas`
--

INSERT INTO `mesas` (`id`, `name`, `capacity`, `status`) VALUES
(1, 'Mesa 1', 4, 'Disponible'),
(2, 'Mesa 2', 6, 'Disponible'),
(11, 'Mesa 3', 5, 'Disponible'),
(12, 'Mesa 4', 5, 'Disponible'),
(13, 'Mesa 5', 5, 'Disponible'),
(14, 'Mesa 6', 5, 'Disponible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `table_id` int(11) NOT NULL,
  `client_name` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` enum('Pendiente','En preparación','Listo','Entregado','Esperando Pago','Pagado') DEFAULT 'Pendiente',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `orders`
--

INSERT INTO `orders` (`id`, `table_id`, `client_name`, `user_id`, `status`, `created_at`, `updated_at`) VALUES
(72, 1, 'Matias', 1, 'Listo', '2024-12-01 23:15:25', '2024-12-02 01:24:21'),
(73, 2, 'Marco', 3, 'Pagado', '2024-12-01 23:20:21', '2024-12-02 01:09:50'),
(74, 11, 'Pedro', 1, 'Pagado', '2024-12-01 23:20:46', '2024-12-02 01:09:56'),
(75, 14, 'Carol', 3, 'Listo', '2024-12-02 00:26:43', '2024-12-02 00:27:19'),
(76, 13, 'Marco', 1, 'Listo', '2024-12-02 00:38:16', '2024-12-02 00:38:34'),
(77, 11, 'Pedro', 3, 'Pendiente', '2024-12-02 00:44:59', '2024-12-02 00:44:59'),
(78, 11, 'Raul', 1, 'Pagado', '2024-12-02 01:28:37', '2024-12-02 01:31:47'),
(79, 12, 'Gimena', 3, 'Pendiente', '2024-12-02 01:32:23', '2024-12-02 01:32:23'),
(80, 12, 'Pedro', NULL, 'Pendiente', '2024-12-02 01:45:26', '2024-12-02 01:45:26'),
(81, 2, 'Raul', NULL, 'Pendiente', '2024-12-02 01:56:18', '2024-12-02 01:56:18'),
(82, 11, 'Esteban', NULL, 'Pendiente', '2024-12-02 01:59:24', '2024-12-02 01:59:24'),
(83, 14, 'Rodrigo', NULL, 'Pendiente', '2024-12-02 02:00:47', '2024-12-02 02:00:47'),
(84, 14, 'Rodrigo', 3, 'Pagado', '2024-12-02 02:02:54', '2024-12-02 02:09:52'),
(85, 13, 'matias', 1, 'Pagado', '2024-12-02 03:25:54', '2024-12-02 03:33:15'),
(86, 1, 'matias', NULL, 'Listo', '2024-12-02 07:15:53', '2024-12-02 07:16:32'),
(87, 1, 'Carol', 3, 'Entregado', '2024-12-02 07:23:39', '2024-12-02 07:25:20'),
(88, 1, 'roberto', 3, 'Pagado', '2024-12-02 07:27:34', '2024-12-02 07:30:06');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `menu_id`, `quantity`) VALUES
(128, 72, 65, 1),
(129, 73, 110, 1),
(130, 73, 111, 1),
(131, 73, 84, 1),
(132, 73, 94, 1),
(133, 74, 66, 1),
(134, 74, 70, 1),
(136, 75, 110, 2),
(137, 75, 71, 1),
(138, 76, 106, 1),
(139, 77, 94, 1),
(140, 78, 109, 1),
(141, 78, 110, 1),
(142, 78, 106, 2),
(143, 78, 107, 1),
(144, 79, 81, 1),
(145, 79, 78, 1),
(146, 80, 115, 1),
(147, 81, 108, 2),
(148, 82, 108, 2),
(149, 82, 84, 1),
(150, 82, 85, 1),
(151, 84, 109, 2),
(152, 84, 70, 2),
(153, 84, 114, 1),
(154, 84, 98, 1),
(155, 84, 110, 2),
(156, 84, 111, 1),
(157, 85, 109, 1),
(158, 85, 84, 1),
(159, 85, 108, 1),
(160, 85, 71, 1),
(161, 86, 109, 1),
(162, 86, 110, 1),
(163, 87, 109, 1),
(164, 87, 108, 1),
(165, 88, 109, 2),
(167, 88, 98, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `order_history`
--

CREATE TABLE `order_history` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `previous_status` enum('Pendiente','En preparación','Listo','Entregado') DEFAULT NULL,
  `new_status` enum('Pendiente','En preparación','Listo','Entregado') DEFAULT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `old_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Administrador', '2024-11-23 20:19:44', '2024-11-23 20:19:44'),
(2, 'Cocina', '2024-11-23 20:19:44', '2024-11-23 20:19:44'),
(3, 'Mesero', '2024-11-23 20:19:44', '2024-11-23 20:19:44');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@example.com', '0192023a7bbd73250516f069df18b500', 1, '2024-11-23 20:20:10', '2024-11-23 20:20:10'),
(2, 'Cocinero', 'cocina@example.com', '8da21b93c854ee7492014ac709754fa0', 2, '2024-11-23 20:20:10', '2024-11-23 20:20:10'),
(3, 'Mesero', 'mesero@example.com', '487556edb1da2a3e67ea07505f3e47b1', 3, '2024-11-23 20:20:10', '2024-11-23 20:20:10'),
(9, 'Maria Jose Altamirano', 'MariaJ@latatemada.com', '1e5d268bd22560fefad56ad09c232386', 1, '2024-12-02 03:01:04', '2024-12-02 03:01:04');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indices de la tabla `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Indices de la tabla `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indices de la tabla `order_history`
--
ALTER TABLE `order_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indices de la tabla `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `permission_id` (`permission_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT de la tabla `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de la tabla `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT de la tabla `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT de la tabla `order_history`
--
ALTER TABLE `order_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`);

--
-- Filtros para la tabla `order_history`
--
ALTER TABLE `order_history`
  ADD CONSTRAINT `order_history_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_history_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `role_permissions_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_permissions_ibfk_2` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
